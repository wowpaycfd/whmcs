<?php
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

function verifyWebhook($secret) {
    $headers = getallheaders();
    $signature = $headers['X-WowPay-Signature'] ?? '';
    $timestamp = $headers['X-WowPay-Timestamp'] ?? '';
    $payload = file_get_contents('php://input');
    
    if (empty($signature) {
        http_response_code(400);
        die(json_encode(['status' => 'error', 'message' => 'Missing signature']));
    }
    
    if (abs(time() - (int)$timestamp) > 300) {
        http_response_code(401);
        die(json_encode(['status' => 'error', 'message' => 'Expired request']));
    }
    
    $expectedSig = hash_hmac('sha256', $timestamp . $payload, $secret);
    if (!hash_equals($expectedSig, $signature)) {
        http_response_code(403);
        die(json_encode(['status' => 'error', 'message' => 'Invalid signature']));
    }
    
    return json_decode($payload, true);
}

try {
    $gatewayParams = getGatewayVariables('wowpay');
    if (!$gatewayParams['type']) {
        http_response_code(404);
        die(json_encode(['status' => 'error', 'message' => 'Gateway not active']));
    }

    $webhookData = verifyWebhook($gatewayParams['webhook_secret']);
    
    // Validate required fields
    $required = ['payment_id', 'status', 'amount', 'orderid'];
    foreach ($required as $field) {
        if (!isset($webhookData[$field])) {
            http_response_code(400);
            die(json_encode(['status' => 'error', 'message' => "Missing $field"]));
        }
    }

    // Get transaction
    $transaction = select_query('mod_wowpay', '*', ['transactionid' => $webhookData['payment_id']]);
    if (!$transaction || !mysql_num_rows($transaction)) {
        http_response_code(404);
        die(json_encode(['status' => 'error', 'message' => 'Transaction not found']));
    }
    $txn = mysql_fetch_assoc($transaction);
    
    // Update transaction record
    update_query('mod_wowpay', [
        'status' => strtolower($webhookData['status']),
        'updated_at' => date('Y-m-d H:i:s')
    ], ['id' => $txn['id']]);

    // Process based on status
    switch (strtolower($webhookData['status'])) {
        case 'success':
            addInvoicePayment(
                $txn['invoiceid'],
                $webhookData['payment_id'],
                $webhookData['amount'],
                '',
                'wowpay'
            );
            logTransaction('WowPay', $webhookData, 'Successful');
            break;
            
        case 'failed':
            update_query('tblinvoices', [
                'status' => 'Unpaid',
                'notes' => 'Payment failed: ' . ($webhookData['message'] ?? '')
            ], ['id' => $txn['invoiceid']]);
            logTransaction('WowPay', $webhookData, 'Failed');
            break;
            
        case 'pending':
            logTransaction('WowPay', $webhookData, 'Pending');
            break;
            
        default:
            http_response_code(400);
            die(json_encode(['status' => 'error', 'message' => 'Invalid status']));
    }

    http_response_code(200);
    echo json_encode(['status' => 'success']);
    
} catch (Exception $e) {
    http_response_code(500);
    logActivity("WowPay Webhook Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}